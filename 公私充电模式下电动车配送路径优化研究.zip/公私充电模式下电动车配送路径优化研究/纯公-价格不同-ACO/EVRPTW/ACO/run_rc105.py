import os
from acsd import AntColonySystem
from evrptw_config import EvrptwGraph
import pandas as pd
import yaml
import csv


def load_configs(general_config_file, aco_config_file) -> dict:
    configs = {}
    with open(general_config_file, "r") as file:
        configs["general"] = yaml.safe_load(file)
    with open(aco_config_file, "r") as file:
        configs["aco"] = yaml.safe_load(file)["aco_config"]
    return configs


def run_single_macs(
        file_path, max_iter, ants_num, alpha, beta, q0, rho, k1, k2, apply_local_search
) -> tuple[list, list]:
    # 与原run_macs功能一致，但去掉了run参数（因为只运行一次）
    graph = EvrptwGraph(file_path, rho)
    macs_instance = AntColonySystem(
        graph, ants_num, max_iter, alpha, beta, q0, k1, k2, apply_local_search
    )
    (
        _,
        c_test_history,
        time_history,
        penalty_history,
        improvement_iter_history,
        num_vehicles,
        improvement_path,
    ) = macs_instance._ACS_DIST_G(apply_local_search)

    path_details = []
    for idx, path in enumerate(improvement_path):
        node_types = [graph.nodes[idx].node_type for idx in path]
        coordinates = graph.get_coordinates_from_path(path)
        path_detail = {
            "numer_of_improvement": idx,
            "path": path,
            "node_types": node_types,
            "coordinates": coordinates,
            "num_vehicles": num_vehicles,
        }
        path_details.append(path_detail)

    improvements = []
    for idx, improvement_time in enumerate(improvement_iter_history):
        improvement_data = {
            "improvement_iteration": improvement_time,
            "fitness_improvement": c_test_history[idx],
            "penalty": penalty_history[idx],
            "time": time_history[idx],
            "num_vehicles": num_vehicles,
            "path": improvement_path[idx],
        }
        improvements.append(improvement_data)

    return improvements, path_details


def save_single_results(improvements, path_details, result_dir):
    # 保存单次运行结果
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)

    # 保存fitness结果
    df_improve = pd.DataFrame(improvements)
    df_improve.to_csv(os.path.join(result_dir, "fitness_result.csv"), index=False)

    # 保存路径细节
    df_path = pd.DataFrame(path_details)
    df_path["coordinates"] = df_path["coordinates"].apply(
        lambda coords: ";".join([f"({x},{y})" for x, y in coords])
    )
    df_path.to_csv(os.path.join(result_dir, "path_results.csv"), index=False)

    # 计算并添加最后一次迭代的fitness（因只运行一次，直接取最后一条）
    last_fitness = improvements[-1]["fitness_improvement"] if improvements else None
    with open(os.path.join(result_dir, "fitness_result.csv"), "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Last Fitness", last_fitness])


if __name__ == "__main__":
    # 配置文件路径（保持不变）
    general_config_file = "config/dask_config.yaml"
    aco_config_file = "config/aco_config.yaml"
    configs = load_configs(general_config_file, aco_config_file)
    aco_config = configs["aco"]

    # ********** 修改这里：指定单个txt实例的路径 **********
    target_instance_path = "paper_total_instances/rc105_21.txt"  # 替换为你的目标文件
    # **************************************************

    # 结果保存目录（以实例文件名创建）
    instance_name = os.path.splitext(os.path.basename(target_instance_path))[0]
    result_dir = os.path.join("results", instance_name + "_single_run")

    # 执行单次运行
    improvements, path_details = run_single_macs(
        file_path=target_instance_path,
        max_iter=aco_config["max_iter"],
        ants_num=aco_config["ants_num"],
        alpha=aco_config["alpha"],
        beta=aco_config["beta"],
        q0=aco_config["q0"],
        rho=aco_config["rho"],
        k1=aco_config["k1"],
        k2=aco_config["k2"],
        apply_local_search=aco_config["apply_local_search"]
    )

    # 保存结果
    save_single_results(improvements, path_details, result_dir)
    print(f"单次运行完成，结果保存在：{result_dir}")