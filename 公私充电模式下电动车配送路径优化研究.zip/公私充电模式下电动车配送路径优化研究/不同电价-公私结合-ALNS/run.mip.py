from mip_model import milp_model  # 替换为你的MILP代码文件名（不含.py）

if __name__ == "__main__":
    # 1. 定义实例文件路径（替换为你的实例文件位置）
    instance_path = "_instances/c101_21ceshi.txt"  # 相对路径或绝对路径

    # 2. 调用MILP模型求解
    # 函数返回：(最优目标值, 车辆数, 求解时间)
    objective_value, num_vehicles, solving_time = milp_model(instance_path)

    # 3. 解析并打印结果
    print(f"求解时间：{solving_time:.2f}秒")
    if objective_value == -1:
        print("未找到可行解（超过时间限制）")
    else:
        print(f"最优总距离：{objective_value:.2f}")  # 目标函数是最小化总距离
        print(f"使用车辆数：{num_vehicles}")