import matplotlib.pyplot as plt
import numpy as np

# ---------------------- 1. 全局字体与显示设置（确保中文/符号正常）
plt.rcParams["font.family"] = ["SimHei", "Arial"]  # 兼容中文字体
plt.rcParams["font.size"] = 10  # 基础字体大小
plt.rcParams["axes.titlesize"] = 14  # 标题字体大小
plt.rcParams["axes.labelsize"] = 12  # 坐标轴标签大小
plt.rcParams["legend.fontsize"] = 10  # 图例字体大小
plt.rcParams["xtick.labelsize"] = 9  # X轴刻度大小
plt.rcParams["ytick.labelsize"] = 9  # Y轴刻度大小
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示异常

# ---------------------- 2. 基础节点数据定义（含新增私营充电桩）
# 2.1 配送中心（起点=终点，路径闭合）
depot = {"StringID": "D0", "x": 35.0, "y": 35.0}
depot_end = {"StringID": "D0_end", "x": 35.0, "y": 35.0}

# 2.2 公共充电桩（原有9个，ID：S1、S4、S5、S6、S9、S11、S13、S17、S19）
public_stations = [
    {"StringID": "S1", "x": 64.0, "y": 37.0},
    {"StringID": "S4", "x": 57.0, "y": 65.0},
    {"StringID": "S5", "x": 29.0, "y": 59.0},
    {"StringID": "S6", "x": 34.0, "y": 71.0},
    {"StringID": "S9", "x": 18.0, "y": 41.0},
    {"StringID": "S11", "x": 14.0, "y": 20.0},
    {"StringID": "S13", "x": 21.0, "y": 22.0},
    {"StringID": "S17", "x": 51.0, "y": 7.0},
    {"StringID": "S19", "x": 64.0, "y": 19.0}
]

# 2.3 私营充电桩（新增4个，数据来自你提供的S2、S3、S7、S10）
private_stations = [
    {"StringID": "S2", "x": 27.0, "y": 40.0},  # 私营：x=27.0, y=40.0
    {"StringID": "S3", "x": 63.0, "y": 60.0},  # 私营：x=63.0, y=60.0
    {"StringID": "S7", "x": 27.0, "y": 17.0},  # 私营：x=27.0, y=17.0
    {"StringID": "S10", "x": 16.0, "y": 38.0} ,
    {"StringID": "S15", "x": 65.0, "y": 23.0}# 私营：x=16.0, y=38.0
]

# 2.4 客户节点（C1~C50，坐标固定，确保与路径ID匹配）
customers = [
    {"StringID": "C1", "x": 41.0, "y": 49.0},
    {"StringID": "C2", "x": 35.0, "y": 17.0},
    {"StringID": "C3", "x": 55.0, "y": 45.0},
    {"StringID": "C4", "x": 55.0, "y": 20.0},
    {"StringID": "C5", "x": 15.0, "y": 30.0},
    {"StringID": "C6", "x": 25.0, "y": 30.0},
    {"StringID": "C7", "x": 20.0, "y": 50.0},
    {"StringID": "C8", "x": 10.0, "y": 43.0},
    {"StringID": "C9", "x": 55.0, "y": 60.0},
    {"StringID": "C10", "x": 30.0, "y": 60.0},
    {"StringID": "C11", "x": 20.0, "y": 65.0},
    {"StringID": "C12", "x": 50.0, "y": 35.0},
    {"StringID": "C13", "x": 30.0, "y": 25.0},
    {"StringID": "C14", "x": 15.0, "y": 10.0},
    {"StringID": "C15", "x": 30.0, "y": 5.0},
    {"StringID": "C16", "x": 10.0, "y": 20.0},
    {"StringID": "C17", "x": 5.0, "y": 30.0},
    {"StringID": "C18", "x": 20.0, "y": 40.0},
    {"StringID": "C19", "x": 15.0, "y": 60.0},
    {"StringID": "C20", "x": 45.0, "y": 65.0},
    {"StringID": "C21", "x": 45.0, "y": 20.0},
    {"StringID": "C22", "x": 45.0, "y": 10.0},
    {"StringID": "C23", "x": 55.0, "y": 5.0},
    {"StringID": "C24", "x": 65.0, "y": 35.0},
    {"StringID": "C25", "x": 65.0, "y": 20.0},
    {"StringID": "C26", "x": 45.0, "y": 30.0},
    {"StringID": "C27", "x": 35.0, "y": 40.0},
    {"StringID": "C28", "x": 41.0, "y": 37.0},
    {"StringID": "C29", "x": 64.0, "y": 42.0},
    {"StringID": "C30", "x": 40.0, "y": 60.0},
    {"StringID": "C31", "x": 31.0, "y": 52.0},
    {"StringID": "C32", "x": 35.0, "y": 69.0},
    {"StringID": "C33", "x": 53.0, "y": 52.0},
    {"StringID": "C34", "x": 65.0, "y": 55.0},
    {"StringID": "C35", "x": 63.0, "y": 65.0},
    {"StringID": "C36", "x": 2.0, "y": 60.0},
    {"StringID": "C37", "x": 20.0, "y": 20.0},
    {"StringID": "C38", "x": 5.0, "y": 5.0},
    {"StringID": "C39", "x": 60.0, "y": 12.0},
    {"StringID": "C40", "x": 40.0, "y": 25.0},
    {"StringID": "C41", "x": 42.0, "y": 7.0},
    {"StringID": "C42", "x": 24.0, "y": 12.0},
    {"StringID": "C43", "x": 23.0, "y": 3.0},
    {"StringID": "C44", "x": 11.0, "y": 14.0},
    {"StringID": "C45", "x": 6.0, "y": 38.0},
    {"StringID": "C46", "x": 2.0, "y": 48.0},
    {"StringID": "C47", "x": 8.0, "y": 56.0},
    {"StringID": "C48", "x": 13.0, "y": 52.0},
    {"StringID": "C49", "x": 6.0, "y": 68.0},
    {"StringID": "C50", "x": 47.0, "y": 47.0}
]

# ---------------------- 3. 构建节点查找字典（快速通过ID获取坐标）
all_points = {
    depot["StringID"]: depot,
    depot_end["StringID"]: depot_end
}
# 加入公共充电桩
for station in public_stations:
    all_points[station["StringID"]] = station
# 加入私营充电桩（关键：确保路径中的S2/S3/S7/S10能找到坐标）
for station in private_stations:
    all_points[station["StringID"]] = station
# 加入所有客户
for customer in customers:
    all_points[customer["StringID"]] = customer

# ---------------------- 4. 最新11辆车最优路径（完全匹配你提供的数据）
vehicle_routes = {
    1: ['D0', 'C40', 'C21', 'C2', 'C6', 'S2', 'C27', 'C26', 'C28', 'D0_end'],
    2: ['D0', 'C22', 'C15', 'C42', 'S7', 'C37', 'S13', 'C13', 'D0_end'],
    3: ['D0', 'C31', 'C1', 'C50', 'C29', 'S1', 'C24', 'C12', 'D0_end'],
    4: ['D0', 'S9', 'C8', 'C46', 'C17', 'C45', 'S9', 'C18', 'S10', 'C5', 'D0_end'],
    5: ['D0', 'C16', 'C44', 'C14', 'S13', 'D0_end'],
    6: ['D0', 'C3', 'C33', 'C9', 'C34', 'S3', 'C35', 'C20', 'C30', 'D0_end'],
    7: ['D0', 'C39', 'S19', 'C4', 'C23', 'C25', 'S19', 'D0_end'],
    8: ['D0', 'S13', 'C43', 'C38', 'S11', 'S13', 'C41', 'D0_end'],
    9: ['D0', 'C48', 'C10', 'S5', 'D0_end'],
    10: ['D0', 'S5', 'C11', 'C19', 'C36', 'C47', 'S9', 'S2', 'D0_end'],
    11: ['D0', 'S5', 'C32', 'C7', 'S5', 'C49', 'S2', 'D0_end']
}

# ---------------------- 5. 可视化配置（区分公私充电桩，提升路径辨识度）
# 5.1 配色方案：11辆车高对比度颜色（顺序对应车辆1~11）
vehicle_colors = [
    '#FF5733', '#33FF57', '#3357FF', '#F3FF33', '#FF33F3',
    '#33FFF3', '#F333FF', '#FF9933', '#99FF33', '#33FF99',
    '#3399FF'
]

# 5.2 节点样式配置（明确区分类型）
node_styles = {
    "depot": {"marker": "o", "color": "red", "size": 200, "edgecolor": "darkred", "label": "配送中心（D0）"},
    "public_station": {"marker": "^", "color": "lightblue", "size": 100, "edgecolor": "darkblue",
                       "label": "公共充电桩（S1/S4等）"},
    "private_station": {"marker": "v", "color": "lightsalmon", "size": 100, "edgecolor": "darkorange",
                        "label": "私营充电桩（S2/S3/S7/S10）"},
    "customer": {"marker": "s", "color": "lightgreen", "size": 60, "edgecolor": "darkgreen", "label": "客户（C1~C50）"}
}

# ---------------------- 6. 图表绘制与美化
# 初始化画布（适配11条路径+新增充电桩，避免拥挤）
plt.figure(figsize=(12, 10))

# 6.1 绘制各类节点（按配置的样式区分）
# 1. 客户节点
c_x = [c["x"] for c in customers]
c_y = [c["y"] for c in customers]
plt.scatter(
    c_x, c_y, marker=node_styles["customer"]["marker"],
    color=node_styles["customer"]["color"], s=node_styles["customer"]["size"],
    edgecolors=node_styles["customer"]["edgecolor"], linewidth=0.8, alpha=0.9,
    label=node_styles["customer"]["label"]
)

# 2. 公共充电桩节点
public_x = [s["x"] for s in public_stations]
public_y = [s["y"] for s in public_stations]
plt.scatter(
    public_x, public_y, marker=node_styles["public_station"]["marker"],
    color=node_styles["public_station"]["color"], s=node_styles["public_station"]["size"],
    edgecolors=node_styles["public_station"]["edgecolor"], linewidth=0.8, alpha=0.9,
    label=node_styles["public_station"]["label"]
)

# 3. 私营充电桩节点（新增，用倒三角形区分公共充电桩）
private_x = [s["x"] for s in private_stations]
private_y = [s["y"] for s in private_stations]
plt.scatter(
    private_x, private_y, marker=node_styles["private_station"]["marker"],
    color=node_styles["private_station"]["color"], s=node_styles["private_station"]["size"],
    edgecolors=node_styles["private_station"]["edgecolor"], linewidth=0.8, alpha=0.9,
    label=node_styles["private_station"]["label"]
)

# 4. 配送中心节点（突出显示）
plt.scatter(
    depot["x"], depot["y"], marker=node_styles["depot"]["marker"],
    color=node_styles["depot"]["color"], s=node_styles["depot"]["size"],
    edgecolors=node_styles["depot"]["edgecolor"], linewidth=1.2, alpha=1.0,
    label=node_styles["depot"]["label"]
)

# 6.2 绘制11辆车的最优路径
for vehicle_id, route in vehicle_routes.items():
    # 提取当前车辆路径的X/Y坐标（通过all_points字典查找）
    x_coords = [all_points[point_id]["x"] for point_id in route]
    y_coords = [all_points[point_id]["y"] for point_id in route]

    # 匹配车辆颜色（车辆1→索引0，以此类推）
    color_idx = vehicle_id - 1
    # 绘制路径线条（线宽2.2，透明度0.85，避免遮挡节点）
    plt.plot(
        x_coords, y_coords, color=vehicle_colors[color_idx], linewidth=2.2,
        alpha=0.85, zorder=1  # zorder=1确保路径在节点下方
    )

    # 为路径添加车辆标识（用于图例区分）
    plt.plot([], [], color=vehicle_colors[color_idx], linewidth=2.2, label=f'车辆 {vehicle_id}')

# 6.3 图表标注与布局优化
# 坐标轴与标题
plt.xlabel("X 坐标（单位：km）", fontweight="bold", labelpad=10)
plt.ylabel("Y 坐标（单位：km）", fontweight="bold", labelpad=10)
plt.title(
    "公私充电桩最优路径图",
    fontweight="bold", pad=20, fontsize=16
)

# 图例：右侧分2列显示（避免过长），带阴影提升美观度
plt.legend(
    loc="center left", bbox_to_anchor=(1, 0.5), ncol=1,
    frameon=True, shadow=True, framealpha=0.9, fancybox=True
)

# 网格线：浅灰色虚线，辅助读坐标但不干扰路径
plt.grid(True, alpha=0.3, color="lightgray", linestyle="--", linewidth=0.8)

# 等比例坐标轴：确保欧几里得距离可视化准确（无拉伸）
plt.axis("equal")

# 调整布局：防止标题、图例被截断
plt.tight_layout()

# ---------------------- 7. 保存与显示图表
# 高清保存（DPI=300），白色背景适配文档插入
plt.savefig(
    "11辆车_含私营充电桩最优路径图.png", dpi=300, bbox_inches="tight",
    facecolor="white", edgecolor="none"
)
# 弹出窗口显示图表
plt.show()