from ALNS import ALNS  # 导入ALNS类
from helper_function import Helper  # 导入辅助计算类
import matplotlib.pyplot as plt  # 导入绘图库
import numpy as np

plt.rcParams["font.family"] = ["SimHei"]
if __name__ == "__main__":
    # 1. 定义实例文件路径
    instance_path = "_instances/r105_50.txt"  # 替换为你的实例文件路径

    # 2. 实例化ALNS算法
    alns = ALNS(file=instance_path)

    # 3. 获取参数（用于初始化Helper计算成本）
    parameters = alns.parameters  # 从ALNS实例中获取问题参数
    helper = Helper(parameters)  # 实例化辅助计算类

    # 4. 运行ALNS算法
    result = alns.run(
        N=500,  # 迭代次数
        sigma1=30,
        sigma2=20,
        sigma3=10,
        epsilon=0.9994  # 温度衰减系数
    )

    # 5. 解析结果
    best_distance, best_vehicles, initial_distance, initial_vehicles, duration, best_route,cost_history = result

    # 6. 计算并输出最优解的总成本
    best_total_cost = helper.total_cost(best_route)  # 调用总成本计算方法
    # （可选）计算初始解的总成本用于对比
    initial_solution = alns.initial.initial_solution()  # 获取初始解
    initial_total_cost = helper.total_cost(initial_solution)
    # 4. 处理成本历史数据
    iterations = [item[0] for item in cost_history]  # 迭代次数
    costs = [item[1] for item in cost_history]       # 对应迭代的最优成本

    # 5. 绘制成本迭代图
    plt.figure(figsize=(10, 6))  # 设置图大小

    # 绘制成本曲线
    plt.plot(iterations, costs, color='b', linewidth=1.5, label='最优总成本')

    # 添加初始成本和最终成本的参考线
    initial_cost = costs[0]
    final_cost = costs[-1]
    plt.axhline(y=initial_cost, color='r', linestyle='--', label=f'初始成本: {initial_cost:.2f}')
    plt.axhline(y=final_cost, color='g', linestyle='--', label=f'最终成本: {final_cost:.2f}')

    # 设置图表标题和坐标轴标签
    plt.title('ALNS算法迭代过程中的总成本变化', fontsize=14)
    plt.xlabel('迭代次数', fontsize=12)
    plt.ylabel('总成本', fontsize=12)
    plt.grid(alpha=0.3)  # 网格线
    plt.legend()  # 显示图例

    # 保存图片（可选）
    #plt.savefig('alns_cost_iteration.png', dpi=300, bbox_inches='tight')

    # 显示图片
    plt.show()


    # 7. 打印结果
    print(f"算法运行时间：{duration:.2f}秒")
    print("=" * 50)
    print("初始解：")
    print(f"  总距离：{initial_distance:.2f}")
    print(f"  车辆数：{initial_vehicles}")
    print(f"  总成本：{initial_total_cost:.2f}")
    print("=" * 50)
    print("最优解：")
    print(f"  总距离：{best_distance:.2f}")
    print(f"  车辆数：{best_vehicles}")
    print(f"  总成本：{best_total_cost:.2f}")  # 输出最优总成本
    print("=" * 50)
    print("最优路径：")
    for i, route in enumerate(best_route, 1):
        print(f"  车辆{i}：{route}")

"""
from ALNS import ALNS  # 导入ALNS类

if __name__ == "__main__":
    # 1. 定义实例文件路径（替换为你的实例文件位置）
    instance_path = "_instances/c101C5.txt"  # 相对路径（假设脚本与_instances同级）
    # 若路径报错，用绝对路径：instance_path = "D:/projects/_instances/c101C5.txt"

    # 2. 实例化ALNS算法
    alns = ALNS(file=instance_path)

    # 3. 调用run方法运行算法（可自定义超参数，或用默认值）
    # 超参数说明：
    # N：总迭代次数（默认2500，越大可能越优但耗时更长）
    # sigma1-3：操作评分（影响自适应权重）
    # rho：权重更新系数（默认0.25）
    # epsilon：温度衰减系数（默认0.9994，越小降温越快）
    result = alns.run(
        N=500,          # 增加迭代次数（如需更优解）
        sigma1=30,
        sigma2=20,
        sigma3=10,
        epsilon=0.9   # 减缓降温速度，增强探索
    )

    # 4. 解析并打印结果
    best_distance, best_vehicles, initial_distance, initial_vehicles, duration, best_route = result
    print(f"算法运行时间：{duration:.2f}秒")
    print(f"初始解：总距离={initial_distance:.2f}，车辆数={initial_vehicles}")
    print(f"最优解：总距离={best_distance:.2f}，车辆数={best_vehicles}")
    print("最优路径：")
    for i, route in enumerate(best_route, 1):
        print(f"车辆{i}：{route}")
        
   result={'S1': 0.8175075286558668, 'S4': 0.9925205228583835, 'S5': 0.956247516704176,
                'S6': 1.3155298499148087, 'S9': 1.273689641196038, 'S11': 1.4245256973933917, 'S13': 0.8608571828405913,
                    'S17': 1.0953452737796894, 'S19': 0.8208580536066493}
"""