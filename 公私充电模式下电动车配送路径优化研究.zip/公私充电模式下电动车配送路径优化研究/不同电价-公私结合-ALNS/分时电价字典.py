def scale_dict_values(original_dict, factor):
    """将字典中的所有值乘以指定倍数，返回新字典"""
    return {k: v * factor for k, v in original_dict.items()}

# 原始数据
result = {
    'S1': 0.8175075286558668,
    'S2': 0.6,
    'S3': 0.6,
    'S4': 0.9925205228583835,
    'S5': 0.956247516704176,
    'S6': 1.3155298499148087,
    'S7': 0.6,
    'S9': 1.273689641196038,
    'S10': 0.6,
    'S11': 1.4245256973933917,
    'S13': 0.8608571828405913,
    'S17': 1.0953452737796894,
    'S19': 0.8208580536066493
}

# 示例：乘以3倍
scaled_result_1 = scale_dict_values(result, 0.5)
scaled_result_2 = scale_dict_values(result, 1.5)

# 输出结果（字典形式）
print("变换后0.5倍的字典：")
print(scaled_result_1)
print("变换后1.5倍的字典")
print(scaled_result_2)
