import string
from mip_check import MIPCheck
from SI import StationInsertion
from helper_function import Helper
class Heuristic:
    def __init__(self, parameters):
        """
        Take the parameter to initiate a helper instance
        :param parameters: parameter dict of a graph instance
        """
        self.parameters = parameters
        self.checker = MIPCheck(self.parameters)
        self.SI = StationInsertion(self.parameters)
        self.helper = Helper(self.parameters)
        self.clients = self.parameters["clients"]
        self.stations = self.parameters["stations"]
        self.all_nodes = self.parameters["all_nodes"]
        self.depot_start = self.parameters["depot_start"]
        self.depot_end = self.parameters["depot_end"]
        self.demand = self.parameters["demand"]
        self.ready_time = self.parameters["ready_time"]
        self.due_date = self.parameters["due_date"]
        self.service_time = self.parameters["service_time"]
        self.arcs = self.parameters["arcs"]
        self.times = self.parameters["times"]
        self.final_data = self.parameters["final_data"]
        self.original_stations = self.parameters["original_stations"]
        self.Q = self.parameters["Q"]
        self.C = self.parameters["C"]
        self.g = self.parameters["g"]
        self.h = self.parameters["h"]
        self.v = self.parameters["v"]

    def initial_solution(self):
        """
        Function to get the initial feasible solution using heuristic combined with Greedy Station Insertion
        :return: list of routes for an instance
        """
        # create routes containing all feasible sub-route
        routes = []

        # create the first route and add to the routes
        route = ["D0", "D0_end"]
        routes.append(route)

        # create a route and add the nearest to the new route
        removal = self.clients[:]

        # if the removal is not empty, the iteration will not stop
        while removal:
            # define the current route as the last route in the routes list
            # hence now we are working with only one route
            current_route = routes[-1]
            # calculate the best customer with time and cargo constraints
            # define the temporary pointers
            best_insertion: string
            index_insertion: int
            min_distance = 999999
            distance_record = min_distance

            # for this part, we must find the smallest feasible if there is any
            for client in removal:
                for i in range(1, len(current_route)):
                    # calculate the difference, trying to find the best one
                    difference = self.arcs[current_route[i], client] + self.arcs[current_route[i - 1], client] - \
                                 self.arcs[
                                     current_route[i], current_route[i - 1]]
                    if difference < min_distance:
                        # find a smaller one, but check the feasibility first
                        # if feasible, we update the recorders
                        if self.helper.feasible_route(current_route[:i] + [client] + current_route[i:]):
                            min_distance = difference
                            best_insertion = client
                            index_insertion = i

            # after this smaller search, check if the recorder has updated
            # if yes, then we find a smaller feasible customer that can be added to the route and update the current
            if min_distance < distance_record:
                new_route = current_route[:index_insertion] + [best_insertion] + current_route[index_insertion:]
                routes[-1] = new_route
                removal.remove(best_insertion)
            # if after the search, there is no customer can be added to the route
            # we loop again to find the customer with a station
            else:
                # create the candidates and then compare the total distance if feasible
                candidates = []
                for client in removal:
                    for i in range(1, len(current_route)):
                        new_route = current_route[:i] + [client] + current_route[i:]
                        # keep new route with time and cargo constraint, and use greedy station insertion to repair
                        if self.helper.cargo_check(new_route) and self.checker.time(new_route) and not self.checker.energy(
                                new_route):
                            candidates.append(self.SI.greedy_station_insertion_sn(new_route))
                # when the loop finish, we proceed with the situation of all new routes
                # if the candidates are not empty:
                if candidates:
                    # if there is one feasible
                    if any(self.helper.feasible_route(candidate) for candidate in candidates):
                        add_route = min(
                            candidates,
                            key=lambda candidate: self.helper.distance_one_route(candidate) if self.helper.feasible_route(
                                candidate) else float("inf")
                        )
                        routes[-1] = add_route
                        for client in add_route:
                            if client in self.clients and client not in current_route:
                                removal.remove(client)
                    else:
                        if current_route != ["D0", "D0_end"]:
                            routes.append(["D0", "D0_end"])

                        # if the new route construction is already in, meaning the infinite loop is on
                        else:
                            routes[-1] = self.SI.supplement_station_insertion(["D0", removal[0], "D0_end"])
                            removal.remove(removal[0])
                else:
                    # this is because the candidates are empty, since the route cannot meet time or cargo constraint
                    routes.append(["D0", "D0_end"])
        return routes

""" 以成本增量最少为思路初始化路线
class Heuristic:
    def __init__(self, parameters):
        ""
        Take the parameter to initiate a helper instance
        :param parameters: parameter dict of a graph instance
        ""
        self.parameters = parameters
        self.checker = MIPCheck(self.parameters)
        self.SI = StationInsertion(self.parameters)
        self.helper = Helper(self.parameters)
        self.clients = self.parameters["clients"]
        self.stations = self.parameters["stations"]
        self.all_nodes = self.parameters["all_nodes"]
        self.depot_start = self.parameters["depot_start"]
        self.depot_end = self.parameters["depot_end"]
        self.demand = self.parameters["demand"]
        self.ready_time = self.parameters["ready_time"]
        self.due_date = self.parameters["due_date"]
        self.service_time = self.parameters["service_time"]
        self.arcs = self.parameters["arcs"]
        self.times = self.parameters["times"]
        self.final_data = self.parameters["final_data"]
        self.original_stations = self.parameters["original_stations"]
        self.Q = self.parameters["Q"]
        self.C = self.parameters["C"]
        self.g = self.parameters["g"]
        self.h = self.parameters["h"]
        self.v = self.parameters["v"]
        self.transport_cost_per_unit = self.parameters["transport_cost_per_unit"]
        #self.charge_cost_per_unit = self.parameters["charge_cost_per_unit"]
        self.early_penalty_per_unit=self.parameters["early_penalty_per_unit"]
        self.late_penalty_per_unit=self.parameters["late_penalty_per_unit"]
        self.station_charge_cost = parameters["station_charge_cost"]#不同电价

    def initial_solution(self):
        ""
        Function to get the initial feasible solution using heuristic combined with Greedy Station Insertion
        :return: list of routes for an instance
        ""
        # create routes containing all feasible sub-route
        routes = []

        # create the first route and add to the routes
        route = ["D0", "D0_end"]
        routes.append(route)

        # create a route and add the nearest to the new route
        removal = self.clients[:]

        # if the removal is not empty, the iteration will not stop
        while removal:
            # define the current route as the last route in the routes list
            # hence now we are working with only one route
            current_route = routes[-1]
            # calculate the best customer with time and cargo constraints
            # define the temporary pointers
            best_insertion: str
            index_insertion: int
            #min_distance=999999
            min_cost: float = float("inf")
            cost_record = min_cost
            for client in removal:
                for i in range(1, len(current_route)):
                    # 原路径片段：A -> B（current_route[i-1]到current_route[i]）
                    A, B = current_route[i - 1], current_route[i]
                    # 新路径片段：A -> client -> B

                    # 计算原片段的成本（仅运输成本，无充电/惩罚，因无客户）
                    original_transport_cost = self.arcs[A, B] * self.transport_cost_per_unit
                    original_cost = original_transport_cost  # 原片段无其他成本

                    # 计算新片段的成本（运输+可能的时间惩罚）
                    new_transport_cost = (self.arcs[A, client] + self.arcs[client, B]) * self.transport_cost_per_unit

                    # 计算新片段的时间惩罚成本（仅client节点可能产生）
                    # 临时生成新路线片段用于计算到达时间
                    temp_route = [A, client, B]
                    try:
                        arrival_times = self.checker.time_extractor(temp_route)
                        client_arrival_time = arrival_times[1]  # client是第2个节点（索引1）
                        # 客户点的时间惩罚
                        early_penalty = max(0,
                                            1.1*self.ready_time[client] - client_arrival_time) * self.early_penalty_per_unit
                        late_penalty = max(0, client_arrival_time - 0.9*self.due_date[client]) * self.late_penalty_per_unit
                        new_penalty_cost = early_penalty + late_penalty
                    except:
                        new_penalty_cost = 0  # 时间计算失败时暂不计惩罚

                    new_cost = new_transport_cost + new_penalty_cost  # 新片段总成本
                    cost_increment = new_cost - original_cost  # 成本增量

                    # 检查插入后整条路线是否可行
                    new_route = current_route[:i] + [client] + current_route[i:]
                    if self.helper.feasible_route(new_route) and cost_increment < min_cost:
                        min_cost = cost_increment
                        best_insertion = client
                        index_insertion = i

                # 若找到可行插入，更新路线
            if min_cost < cost_record:
                new_route = current_route[:index_insertion] + [best_insertion] + current_route[index_insertion:]
                routes[-1] = new_route
                removal.remove(best_insertion)
            else:
                # 第二步：插入客户后需补充充电站，选择总成本最低的候选路线
                candidates = []
                for client in removal:
                    for i in range(1, len(current_route)):
                        new_route = current_route[:i] + [client] + current_route[i:]
                        if self.helper.cargo_check(new_route) and self.checker.time(
                                new_route) and not self.checker.energy(
                                new_route):
                            repaired_route = self.SI.greedy_station_insertion_sn(new_route)
                            candidates.append(repaired_route)

                if candidates:
                    if any(self.helper.feasible_route(c) for c in candidates):
                        # 用helper的cost_one_route计算总成本（已实现动态成本）
                        add_route = min(
                            candidates,
                            key=lambda c: self.helper.cost_one_route(c) if self.helper.feasible_route(c) else float(
                                "inf")
                        )
                        routes[-1] = add_route
                        for client in add_route:
                            if client in self.clients and client not in current_route:
                                removal.remove(client)
                    else:
                        if current_route != ["D0", "D0_end"]:
                            routes.append(["D0", "D0_end"])
                        else:
                            routes[-1] = self.SI.supplement_station_insertion(["D0", removal[0], "D0_end"])
                            removal.remove(removal[0])
                else:
                    routes.append(["D0", "D0_end"])
        return routes
"""

"""
            # for this part, we must find the smallest feasible if there is any
            for client in removal:
                for i in range(1, len(current_route)):
                    # calculate the difference, trying to find the best one
                    difference = self.arcs[current_route[i], client] + self.arcs[current_route[i - 1], client] - \
                                 self.arcs[
                                     current_route[i], current_route[i - 1]]
                    if difference < min_distance:
                        # find a smaller one, but check the feasibility first
                        # if feasible, we update the recorders
                        if self.helper.feasible_route(current_route[:i] + [client] + current_route[i:]):
                            min_distance = difference
                            best_insertion = client
                            index_insertion = i

            # after this smaller search, check if the recorder has updated
            # if yes, then we find a smaller feasible customer that can be added to the route and update the current
            if min_distance < distance_record:
                new_route = current_route[:index_insertion] + [best_insertion] + current_route[index_insertion:]
                routes[-1] = new_route
                removal.remove(best_insertion)
            # if after the search, there is no customer can be added to the route
            # we loop again to find the customer with a station
            else:
                # create the candidates and then compare the total distance if feasible
                candidates = []
                for client in removal:
                    for i in range(1, len(current_route)):
                        new_route = current_route[:i] + [client] + current_route[i:]
                        # keep new route with time and cargo constraint, and use greedy station insertion to repair
                        if self.helper.cargo_check(new_route) and self.checker.time(new_route) and not self.checker.energy(
                                new_route):
                            candidates.append(self.SI.greedy_station_insertion_sn(new_route))
                # when the loop finish, we proceed with the situation of all new routes
                # if the candidates are not empty:
                if candidates:
                    # if there is one feasible
                    if any(self.helper.feasible_route(candidate) for candidate in candidates):
                        add_route = min(
                            candidates,
                            key=lambda candidate: self.helper.distance_one_route(candidate) if self.helper.feasible_route(
                                candidate) else float("inf")
                        )
                        routes[-1] = add_route
                        for client in add_route:
                            if client in self.clients and client not in current_route:
                                removal.remove(client)
                    else:
                        if current_route != ["D0", "D0_end"]:
                            routes.append(["D0", "D0_end"])

                        # if the new route construction is already in, meaning the infinite loop is on
                        else:
                            routes[-1] = self.SI.supplement_station_insertion(["D0", removal[0], "D0_end"])
                            removal.remove(removal[0])
                else:
                    # this is because the candidates are empty, since the route cannot meet time or cargo constraint
                    routes.append(["D0", "D0_end"])
        return routes
"""

