import matplotlib.pyplot as plt
import numpy as np

# ---------------------- 1. 全局字体设置（确保中文/特殊符号正常显示）
plt.rcParams["font.family"] = ["SimHei", "Arial"]  # 兼容中文字体与英文
plt.rcParams["font.size"] = 10  # 全局基础字体大小
plt.rcParams["axes.titlesize"] = 14  # 图表标题字体大小
plt.rcParams["axes.labelsize"] = 12  # 坐标轴标签字体大小
plt.rcParams["legend.fontsize"] = 10  # 图例字体大小
plt.rcParams["xtick.labelsize"] = 9  # X轴刻度字体大小
plt.rcParams["ytick.labelsize"] = 9  # Y轴刻度字体大小
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示异常问题

# ---------------------- 2. 基础节点数据定义（配送中心、充电桩、客户）
# 配送中心（起点=终点，确保路径闭合）
depot = {"StringID": "D0", "x": 35.0, "y": 35.0}
depot_end = {"StringID": "D0_end", "x": 35.0, "y": 35.0}

# 公共充电桩（Type=f，共9个，坐标与原数据一致）
public_stations = [
    {"StringID": "S1", "x": 64.0, "y": 37.0},
    {"StringID": "S4", "x": 57.0, "y": 65.0},
    {"StringID": "S5", "x": 29.0, "y": 59.0},
    {"StringID": "S6", "x": 34.0, "y": 71.0},
    {"StringID": "S9", "x": 18.0, "y": 41.0},
    {"StringID": "S11", "x": 14.0, "y": 20.0},
    {"StringID": "S13", "x": 21.0, "y": 22.0},
    {"StringID": "S17", "x": 51.0, "y": 7.0},
    {"StringID": "S19", "x": 64.0, "y": 19.0}
]

# 私营充电桩（无数据时保留空列表，避免代码报错）
private_stations = []

# 客户节点（C1~C50，坐标固定，确保与路径中的客户ID匹配）
customers = [
    {"StringID": "C1", "x": 41.0, "y": 49.0},
    {"StringID": "C2", "x": 35.0, "y": 17.0},
    {"StringID": "C3", "x": 55.0, "y": 45.0},
    {"StringID": "C4", "x": 55.0, "y": 20.0},
    {"StringID": "C5", "x": 15.0, "y": 30.0},
    {"StringID": "C6", "x": 25.0, "y": 30.0},
    {"StringID": "C7", "x": 20.0, "y": 50.0},
    {"StringID": "C8", "x": 10.0, "y": 43.0},
    {"StringID": "C9", "x": 55.0, "y": 60.0},
    {"StringID": "C10", "x": 30.0, "y": 60.0},
    {"StringID": "C11", "x": 20.0, "y": 65.0},
    {"StringID": "C12", "x": 50.0, "y": 35.0},
    {"StringID": "C13", "x": 30.0, "y": 25.0},
    {"StringID": "C14", "x": 15.0, "y": 10.0},
    {"StringID": "C15", "x": 30.0, "y": 5.0},
    {"StringID": "C16", "x": 10.0, "y": 20.0},
    {"StringID": "C17", "x": 5.0, "y": 30.0},
    {"StringID": "C18", "x": 20.0, "y": 40.0},
    {"StringID": "C19", "x": 15.0, "y": 60.0},
    {"StringID": "C20", "x": 45.0, "y": 65.0},
    {"StringID": "C21", "x": 45.0, "y": 20.0},
    {"StringID": "C22", "x": 45.0, "y": 10.0},
    {"StringID": "C23", "x": 55.0, "y": 5.0},
    {"StringID": "C24", "x": 65.0, "y": 35.0},
    {"StringID": "C25", "x": 65.0, "y": 20.0},
    {"StringID": "C26", "x": 45.0, "y": 30.0},
    {"StringID": "C27", "x": 35.0, "y": 40.0},
    {"StringID": "C28", "x": 41.0, "y": 37.0},
    {"StringID": "C29", "x": 64.0, "y": 42.0},
    {"StringID": "C30", "x": 40.0, "y": 60.0},
    {"StringID": "C31", "x": 31.0, "y": 52.0},
    {"StringID": "C32", "x": 35.0, "y": 69.0},
    {"StringID": "C33", "x": 53.0, "y": 52.0},
    {"StringID": "C34", "x": 65.0, "y": 55.0},
    {"StringID": "C35", "x": 63.0, "y": 65.0},
    {"StringID": "C36", "x": 2.0, "y": 60.0},
    {"StringID": "C37", "x": 20.0, "y": 20.0},
    {"StringID": "C38", "x": 5.0, "y": 5.0},
    {"StringID": "C39", "x": 60.0, "y": 12.0},
    {"StringID": "C40", "x": 40.0, "y": 25.0},
    {"StringID": "C41", "x": 42.0, "y": 7.0},
    {"StringID": "C42", "x": 24.0, "y": 12.0},
    {"StringID": "C43", "x": 23.0, "y": 3.0},
    {"StringID": "C44", "x": 11.0, "y": 14.0},
    {"StringID": "C45", "x": 6.0, "y": 38.0},
    {"StringID": "C46", "x": 2.0, "y": 48.0},
    {"StringID": "C47", "x": 8.0, "y": 56.0},
    {"StringID": "C48", "x": 13.0, "y": 52.0},
    {"StringID": "C49", "x": 6.0, "y": 68.0},
    {"StringID": "C50", "x": 47.0, "y": 47.0}
]

# ---------------------- 3. 构建节点查找字典（快速通过ID获取坐标）
all_points = {
    depot["StringID"]: depot,
    depot_end["StringID"]: depot_end
}
# 加入公共充电桩
for station in public_stations:
    all_points[station["StringID"]] = station
# 加入私营充电桩（无数据时不影响）
for station in private_stations:
    all_points[station["StringID"]] = station
# 加入所有客户
for customer in customers:
    all_points[customer["StringID"]] = customer

# ---------------------- 4. 最新12辆车最优路径（完全匹配你提供的数据）
vehicle_routes = {
    1: ['D0', 'C40', 'C21', 'C6', 'C18', 'S9', 'C27', 'C26', 'C28', 'D0_end'],
    2: ['D0', 'S17', 'C22', 'C2', 'C15', 'C42', 'C37', 'S13', 'C13', 'D0_end'],
    3: ['D0', 'C31', 'C1', 'C50', 'C29', 'S1', 'C24', 'C12', 'D0_end'],
    4: ['D0', 'S9', 'C8', 'C46', 'C17', 'C45', 'S9', 'C5', 'D0_end'],
    5: ['D0', 'C3', 'C33', 'C9', 'C35', 'S4', 'C20', 'C30', 'D0_end'],
    6: ['D0', 'C39', 'C4', 'S17', 'C23', 'S17', 'C41', 'D0_end'],  # 修正：移除重复的S17
    7: ['D0', 'S5', 'C11', 'C19', 'C49', 'C47', 'S9', 'D0_end'],
    8: ['D0', 'S11', 'C38', 'C16', 'C44', 'C14', 'S13', 'D0_end'],
    9: ['D0', 'C32', 'S5', 'C7', 'C48', 'S5', 'C10', 'D0_end'],
    10: ['D0', 'S9', 'C36', 'S5', 'D0_end'],
    11: ['D0', 'C43', 'S13', 'S9', 'D0_end'],
    12: ['D0', 'C34', 'S1', 'C25', 'S19', 'D0_end']  # 恢复车辆12路径
}

# 12辆车高对比度配色（避免颜色相近导致混淆，顺序对应车辆1~12）
colors = [
    '#FF5733', '#33FF57', '#3357FF', '#F3FF33', '#FF33F3', '#33FFF3',
    '#F333FF', '#FF9933', '#99FF33', '#33FF99', '#3399FF', '#FF66B2'
]

# ---------------------- 5. 图表绘制与美化
# 初始化画布（尺寸适配12条路径，避免拥挤）
plt.figure(figsize=(12, 10))

# 5.1 绘制各类节点（按类型区分样式，提升辨识度）
# 客户节点：绿色正方形（带深绿边框，突出客户位置）
c_x = [c["x"] for c in customers]
c_y = [c["y"] for c in customers]
plt.scatter(
    c_x, c_y, marker="s", color="lightgreen", s=60,
    label="客户（C1~C50）", edgecolors="darkgreen", linewidth=0.8, alpha=0.9
)

# 公共充电桩：蓝色三角形（带深蓝边框，区分于客户）
public_s_x = [s["x"] for s in public_stations]
public_s_y = [s["y"] for s in public_stations]
plt.scatter(
    public_s_x, public_s_y, marker="^", color="lightblue", s=100,
    label="公共充电桩（S1、S4等）", edgecolors="darkblue", linewidth=0.8, alpha=0.9
)
"""
# 私营充电桩：橙色三角形（无数据时自动隐藏，不影响图例）
private_s_x = [s["x"] for s in private_stations]
private_s_y = [s["y"] for s in private_stations]
plt.scatter(
    private_s_x, private_s_y, marker="^", color="lightsalmon", s=100,
    label="私营充电桩", edgecolors="darkorange", linewidth=0.8, alpha=0.9
)
"""
# 配送中心：红色圆形（放大尺寸，突出核心起点/终点）
plt.scatter(
    depot["x"], depot["y"], marker="o", color="red", s=200,
    label="配送中心（D0）", edgecolors="darkred", linewidth=1.2, alpha=1.0
)

# 5.2 绘制12辆车的最优路径
for vehicle_id, route in vehicle_routes.items():
    # 提取当前车辆路径的X/Y坐标序列
    x_coords = [all_points[point_id]["x"] for point_id in route]
    y_coords = [all_points[point_id]["y"] for point_id in route]

    # 绘制路径线条（线宽2，透明度0.8，避免遮挡）
    color_idx = vehicle_id - 1  # 配色与车辆ID一一对应（1→0索引）
    plt.plot(
        x_coords, y_coords, color=colors[color_idx], linewidth=2.2,
        alpha=0.85, zorder=1  # zorder确保路径在节点下方，不遮挡节点
    )

    # 为每条路径添加车辆标识（用于图例区分）
    plt.plot([], [], color=colors[color_idx], linewidth=2.2, label=f'车辆 {vehicle_id}')

# 5.3 图表标注与美化
plt.xlabel("X 坐标（单位：km）", fontweight="bold", labelpad=10)
plt.ylabel("Y 坐标（单位：km）", fontweight="bold", labelpad=10)
plt.title(
    "公用充电桩配送网络最优路径图",
    fontweight="bold", pad=20, fontsize=16
)

# 图例：放在右侧外部，避免遮挡路径（分2列显示，更紧凑）
plt.legend(
    loc="center left", bbox_to_anchor=(1, 0.5), ncol=1,
    frameon=True, shadow=True, framealpha=0.9, fancybox=True
)

# 网格线：浅灰色虚线，辅助读取坐标，不干扰路径
plt.grid(True, alpha=0.3, color="lightgray", linestyle="--", linewidth=0.8)

# 等比例坐标轴：确保欧几里得距离可视化准确（避免坐标拉伸）
plt.axis("equal")

# 调整布局：防止标题、图例被截断
plt.tight_layout()

# ---------------------- 6. 保存与显示
# 高清保存图片（DPI=300，白色背景，避免透明背景适配问题）
plt.savefig(
    "公用充电桩配送网络最优路径图.png", dpi=300, bbox_inches="tight",
    facecolor="white", edgecolor="none"
)
# 显示图表
plt.show()