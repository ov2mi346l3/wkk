import string
from mip_check import MIPCheck


class Helper:
    def __init__(self, parameters):#初始化helper实例
        """
        Take the parameter to initiate a helper instance
        :param parameters: parameter dict of a graph instance
        """
        self.parameters = parameters
        self.checker = MIPCheck(self.parameters)
        self.clients = self.parameters["clients"]
        self.stations = self.parameters["stations"]
        self.all_nodes = self.parameters["all_nodes"]
        self.depot_start = self.parameters["depot_start"]
        self.depot_end = self.parameters["depot_end"]
        self.demand = self.parameters["demand"]
        self.ready_time = self.parameters["ready_time"]
        self.due_date = self.parameters["due_date"]
        self.service_time = self.parameters["service_time"]
        self.arcs = self.parameters["arcs"]
        self.times = self.parameters["times"]
        self.final_data = self.parameters["final_data"]
        self.original_stations = self.parameters["original_stations"]
        self.Q = self.parameters["Q"]
        self.C = self.parameters["C"]
        self.g = self.parameters["g"]
        self.h = self.parameters["h"]
        self.v = self.parameters["v"]#提取原始参数字典的参数
        self.transport_cost_per_unit = self.parameters["transport_cost_per_unit"]
        #self.charge_cost_per_unit = self.parameters["charge_cost_per_unit"] 统一电价
        self.early_penalty_per_unit=self.parameters["early_penalty_per_unit"]
        self.late_penalty_per_unit=self.parameters["late_penalty_per_unit"]
        self.refrigeration_cost_per_min = parameters["refrigeration_cost_per_min"]  # 单位时间制冷成本
        self.damage_rate_per_min = parameters["damage_rate_per_min"]                # 单位时间货损率
        self.product_value = parameters["product_value"] # 货物总价值
        self.station_charge_cost = parameters["station_charge_cost"] #不同电价
        self.vehicle_fixed_cost=parameters["vehicle_fixed_cost"]


    def get_routes_dict(self, incidence_dict):
        """
        这是一个从解决方案中获取所有路线的函数，该解决方案是一个包含列表的列表，即二维数组。
        :param incidence_dict: 由 0 和 1 组成的二进制弧
        :return: 路线列表
        """
        routes = []
        for i in self.all_nodes:
            if incidence_dict["D0", i] == 1:
                routes.append(self.get_route_dict(incidence_dict, ["D0"], i))
        return routes

    def get_route_dict(self, incidence_dict, list_of_nodes, node: str):
        """
        这是一个递归函数，用于从关联字典矩阵中获取一条路径。
        :param incidence_dict: 由 0 和 1 组成的二进制弧
        :param list_of_nodes: 路径列表
        :param node: 当前节点指针
        :return: 表示一条路径的列表
        """
        list_of_nodes.append(node)
        if node == "D0_end":
            return list_of_nodes

        for i in self.all_nodes:
            if incidence_dict[node, i] == 1:
                return self.get_route_dict(incidence_dict, list_of_nodes, i)

    def vehicle_number_dict(self, incidence_dict):
        """
        这是一个从关联字典矩阵中获取车辆数量的函数
        :param incidence_dict: 包含 0 和 1 的二进制弧
        :return: int，解决方案中的车辆数量
        """
        return sum(incidence_dict["D0", j] for j in self.all_nodes)

    def vehicle_number_list(self, routes):
        """
        这是一个从所有路线列表中获取车辆数量的函数
        :param routes: 路线列表
        :return: 列表的长度，即车辆数量
        """
        return len(routes)

    def total_distance_dict(self, incidence_dict):
        """
        这是一个从关联字典矩阵中获取总距离的函数
        :param incidence_dict: 包含 0 和 1 的二进制弧
        :return: 总行驶距离
        """
        return sum(self.arcs[i, j] * incidence_dict[i, j] for i in self.all_nodes for j in self.all_nodes)

    def total_distance_list(self, routes):
        """
        这是一个用于获取所有路线总距离的函数
        :param routes: 所有路线的列表
        :return: 图的总距离
        """
        return sum(self.distance_one_route(route) for route in routes)

    def distance_one_route(self, route):
        """
        这是获取一条路径总距离的函数
        :param route: 节点列表
        :return: 一条路径的距离
        """
        total_distance = 0
        for i in range(len(route)):
            if route[i] == "D0_end":
                break
            else:
                total_distance += self.arcs[route[i], route[i + 1]]
        return total_distance

    # 新增：计算车辆固定总成本
    def vehicle_fixed_total_cost(self, routes):
        """根据路线数量计算总车辆固定成本（每条路线对应一辆车）"""
        num_vehicles = self.vehicle_number_list(routes)  # 复用现有方法获取车辆数量
        return num_vehicles * self.vehicle_fixed_cost

    def transport_cost(self, routes):
        total_distance = self.total_distance_list(routes)  # 复用总距离计算
        return total_distance * self.parameters["transport_cost_per_unit"]
    def charging_cost_one_route(self, route):#不同充电站
        try:
            arrival_energy = self.checker.energy_extractor(route)  # 到达时的能量
            departure_energy = self.checker.energy_extractor_departure(route)  # 离开时的能量
        except:
            return 0  # 路径不可行时不计入

        total_charge = 0
        for i in range(len(route)):
            node = route[i]
            if node in self.stations:  # 仅充电站有充电行为
                # 充电量 = 离开时能量 - 到达时能量
                charge = departure_energy[i] - arrival_energy[i]
                if charge > 0:  # 仅计算实际充电量
                    # 关键修改：用当前充电站的单价计算成本
                    station_unit_cost = self.station_charge_cost[node]  # 获取该充电站的单价
                    total_charge += charge * station_unit_cost  # 充电量 × 该站单价
        return total_charge  # 直接返回该路线的总充电成本（无需再乘全局单价）
    """
    def charging_cost_one_route(self, route):
        try:
            # 获取到达充电站时的能量（y）和离开时的能量（Y）
            arrival_energy = self.checker.energy_extractor(route)  # y[i]
            departure_energy = self.checker.energy_extractor_departure(route)  # Y[i]
        except:
            return 0  # 路径不可行时暂不计入

        total_charge = 0
        for i in range(len(route)):
            node = route[i]
            if node in self.stations:  # 仅充电站有充电行为
                # 充电量 = 离开时能量 - 到达时能量（Y[i] - y[i]）
                charge = departure_energy[i] - arrival_energy[i]
                if charge > 0:  # 仅计算正向充电量
                    total_charge += charge
        return total_charge * self.parameters["charge_cost_per_unit"]
        """
    # 新增：计算总充电成本
    def charging_cost(self, routes):
        return sum(self.charging_cost_one_route(route) for route in routes)

    def time_window_penalty_one_route(self, route):
        try:
            # 获取各节点的到达时间（t[i]）
            arrival_times = self.checker.time_extractor(route)
        except:
            return 0  # 路径不可行时暂不计入

        total_penalty = 0
        for i in range(len(route)):
            node = route[i]
            t = arrival_times[i]
            ready = self.ready_time[node]
            due = self.due_date[node]

            # 早到惩罚：(ready_time - 到达时间) × 单位早到惩罚
            if t < 1.1*ready:
                total_penalty += (1.05*ready - t) * self.parameters["early_penalty_per_unit"]
            # 迟到惩罚：(到达时间 - due_date) × 单位迟到惩罚
            elif t > 0.9*due:
                total_penalty += (t - 0.95*due) * self.parameters["late_penalty_per_unit"]
        return total_penalty

    # 新增：计算总时间窗惩罚成本
    def time_window_penalty(self, routes):
        return sum(self.time_window_penalty_one_route(route) for route in routes)

    def refrigeration_cost_one_route(self, route):
        try:
            # 获取路线各节点的到达时间（t[i]）和离开时间（含服务时间）
            arrival_times = self.checker.time_extractor(route)  # 到达时间列表
            departure_times = []
            for i in range(len(route)):
                # 离开时间 = 到达时间 + 服务时间（客户点有服务时间，仓库/充电站可能为0）
                service_time = self.service_time[route[i]] if route[i] in self.clients else 0
                departure_times.append(arrival_times[i] + service_time)

            # 总运输时间 = 最后一个节点的离开时间 - 第一个节点的到达时间（仓库出发时间）
            total_transport_time = departure_times[-1] - arrival_times[0]  # 单位：分钟
            return total_transport_time * self.refrigeration_cost_per_min

        except:
            return 0  # 路线不可行时不计入

    # 新增：计算单条路线的货损成本（与客户点运输时间相关）
    def damage_cost_one_route(self, route):
        try:
            arrival_times = self.checker.time_extractor(route)  # 各节点到达时间
            total_damage = 0

            for i in range(len(route)):
                node = route[i]
                if node in self.clients:  # 仅客户点计算货损（货物送达时的损耗）
                    # 运输时间 = 到达客户点的时间 - 从仓库出发的时间
                    transport_time = arrival_times[i] - arrival_times[0]  # 单位：分钟

                    damage_rate = self.damage_rate_per_min

                    # 该客户点的货损 = 货物价值 × 运输时间 × 货损率
                    node_damage = self.product_value * transport_time * damage_rate
                    total_damage += node_damage

            return total_damage

        except:
            return 0  # 路线不可行时不计入
    def refrigeration_cost(self, routes):
        return sum(self.refrigeration_cost_one_route(route) for route in routes)

    # 新增：总货损成本（所有路线求和）
    def damage_cost(self, routes):
        return sum(self.damage_cost_one_route(route) for route in routes)

    def total_cost(self, routes):
        return (self.transport_cost(routes) +
                self.charging_cost(routes) +
                self.time_window_penalty(routes)+
                self.refrigeration_cost(routes) +  # 新增制冷成本
                self.damage_cost(routes)+self.vehicle_fixed_total_cost(routes))
    """统一充电桩
    def cost_one_route(self, route):
        ""计算单条路线的总成本（无self.cost时的动态计算）""
        if len(route) < 2:
            return 0

        total_cost = 0

        # 1. 运输成本 = 总距离 × 单位运输成本
        total_distance = self.distance_one_route(route)
        total_cost += total_distance * self.transport_cost_per_unit

        # 2. 充电成本 = 总充电量 × 单位充电成本
        try:
            arrival_energy = self.checker.energy_extractor(route)  # 到达充电站时的能量
            departure_energy = self.checker.energy_extractor_departure(route)  # 离开时的能量
        except:
            arrival_energy = [0] * len(route)
            departure_energy = [0] * len(route)

        for i in range(len(route)):
            node = route[i]
            if node in self.stations:  # 仅充电站有充电行为
                charge = departure_energy[i] - arrival_energy[i]
                if charge > 0:  # 只计算实际充电量
                    total_cost += charge * self.charge_cost_per_unit

        # 3. 时间窗口惩罚成本 = 早到/迟到时间 × 对应单位惩罚
        try:
            arrival_times = self.checker.time_extractor(route)  # 各节点到达时间
        except:
            arrival_times = [0] * len(route)

        for i in range(len(route)):
            node = route[i]
            if node in self.clients:  # 仅客户点有时间窗口惩罚
                t = arrival_times[i]
                ready = self.ready_time[node]
                due = self.due_date[node]
                # 早到惩罚（到达时间 < 最早服务时间）
                if t < ready:
                    total_cost += (ready - t) * self.early_penalty_per_unit
                # 迟到惩罚（到达时间 > 最晚服务时间）
                elif t > due:
                    total_cost += (t - due) * self.late_penalty_per_unit

        return total_cost
        """

    def cost_one_route(self, route):#不同充电桩
        """计算单条路线的总成本（含冷链成本+差异化充电价格）"""
        if len(route) < 2:
            return 0

        total_cost = 0

        # 1. 运输成本 = 总距离 × 单位运输成本（不变）
        total_distance = self.distance_one_route(route)
        total_cost += total_distance * self.transport_cost_per_unit

        # 2. 充电成本 = 各充电站充电量 × 对应站点单价（差异化价格）
        try:
            arrival_energy = self.checker.energy_extractor(route)  # 到达时能量
            departure_energy = self.checker.energy_extractor_departure(route)  # 离开时能量
        except:
            arrival_energy = [0] * len(route)
            departure_energy = [0] * len(route)

        for i in range(len(route)):
            node = route[i]
            if node in self.stations:  # 仅充电站计算充电成本
                charge = departure_energy[i] - arrival_energy[i]  # 充电量
                if charge > 0:
                    # 按当前充电站的单价计算（从station_charge_cost字典获取）
                    station_unit_cost = self.station_charge_cost[node]
                    total_cost += charge * station_unit_cost

        # 3. 时间窗口惩罚成本（不变）
        try:
            arrival_times = self.checker.time_extractor(route)  # 各节点到达时间
        except:
            arrival_times = [0] * len(route)

        for i in range(len(route)):
            node = route[i]
            if node in self.clients:  # 仅客户点有时间惩罚
                t = arrival_times[i]
                ready = self.ready_time[node]
                due = self.due_date[node]
                if t < ready:
                    total_cost += (ready - t) * self.early_penalty_per_unit
                elif t > due:
                    total_cost += (t - due) * self.late_penalty_per_unit

        # 4. 制冷成本 = 总运输时间 × 单位时间制冷成本（新增）
        try:
            # 总运输时间 = 路线终点离开时间 - 起点出发时间（含服务时间）
            departure_times = [arrival_times[i] + self.service_time.get(route[i], 0) for i in range(len(route))]
            total_transport_time = departure_times[-1] - arrival_times[0]  # 单位：分钟
            total_cost += total_transport_time * self.refrigeration_cost_per_min
        except:
            pass  # 时间计算失败时不计入

        # 5. 货损成本 = 各客户点运输时间 × 货损率 × 货物价值（新增）
        try:
            for i in range(len(route)):
                node = route[i]
                if node in self.clients:  # 仅客户点计算货损
                    # 该客户点的运输时间 = 到达时间 - 起点出发时间
                    transport_time = arrival_times[i] - arrival_times[0]  # 单位：分钟
                    damage_rate = self.damage_rate_per_min
                    # 货损成本 = 货物价值 × 运输时间 × 货损率
                    total_cost += self.product_value * transport_time * damage_rate
        except:
            pass  # 时间计算失败时不计入

        return total_cost
    def cargo_check(self, route):
        """
        This is the function to check the cargo feasibility for a route
        :param route: one route of one vehicle
        :return: if the cargo on this route is feasible
        """
        return sum(self.demand[i] for i in route) <= self.C

    def depot_check(self, route):
        """
        This is the function to check if for a route, the start is D0 and the end is D0_end
        :param route: list of nodes of a route
        :return: true if yes and false otherwise
        """
        return route[0] == "D0" and route[-1] == "D0_end" and route.count("D0") == 1 and route.count("D0_end") == 1

    def feasible_route(self, route):
        """
        This is the function to check if the route is completely feasible
        :param route: list of nodes
        :return: true if route is feasible and false otherwise
        """
        return self.checker.time_energy(route) and self.cargo_check(route) and self.depot_check(route)

    def feasible(self, routes):
        return all(self.feasible_route(route) for route in routes)
