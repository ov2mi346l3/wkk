import string
from typing import Any, Dict
import pandas as pd
import numpy as np
import math
import statistics
import random
random.seed(42)


"""
This file contains the functions that extract the parameters and check them for instances
该文件的核心就是将将原始实例文件转换为路径规划算法可直接使用的标准化参数字典
流程为读取节点数据→提取全局参数→生成虚拟充电站→分类节点类型→计算节点属性（距离、时间等）→整合结果。
其中虚拟节点的生成（基于num参数）是为了支持车辆多次访问同一充电站的场景
"""


def get_parameters(file: str, num: int=0) -> Dict[str, Any]:
    """
    Extract parameters from the instance files
    :param file: txt instance file
    :param different_dummy: whether to use dummy with different ID from original charging stations
    :param num: number of dummy for each charging station
    :return: dict storing parameters
    """

    # get the data frame cleaning the parameter description sentences in the last 5 rows
    df = pd.read_csv(file, sep='\s+')
    df_filtered = df.iloc[:-5]#剔除描述行数据

    # convert the data frame to numpy array
    original_data = df_filtered.to_numpy()

    # get the copy of the depot row and change the name
    depot_copy = original_data[0].copy()
    depot_copy[0] = "D0_end"#处理重点仓库节点

    # read lines from text and get the general parameters from last 5 rows
    with open(file, 'r') as file:
        lines = file.readlines()

        for line in lines:
            if line.startswith('Q Vehicle fuel tank capacity'):
                Q = float(line.split('/')[1])
            elif line.startswith('C Vehicle load capacity'):
                C = float(line.split('/')[1])
            elif line.startswith('g inverse refueling rate'):
                g = float(line.split('/')[1])
            elif line.startswith('r fuel consumption rate'):
                h = float(line.split('/')[1])
            elif line.startswith('v average Velocity'):
                v = float(line.split('/')[1])


    # get the number of charging stations and the index of the final station 原始充电站
    final_station_index = np.sum(df_filtered["Type"] == 'f')
    stations_copy = original_data[1:final_station_index + 1].copy()
    original_stations = [str(row[0]) for count, row in enumerate(stations_copy)]

    # replicate all the stations and change the names 虚拟充电站
    replicate_stations = np.tile(stations_copy, (num,1))
    for count, value in enumerate(replicate_stations):
        value[0] = "S_dummy" + str(count)

    # concatenate all the arrays 合并节点数据
    final_data = np.vstack((original_data, depot_copy, replicate_stations))

    # extract the client, charging stations, depots and all nodes 按节点类型分类
    clients = [str(row[0]) for count, row in enumerate(final_data) if str(row[1]) == "c"]
    stations = [str(row[0]) for count, row in enumerate(final_data) if str(row[1]) == "f"]
    all_nodes = [str(row[0]) for count, row in enumerate(final_data)]
    depot_start = ["D0"]
    depot_end = ["D0_end"]

    # extract distance, demand, ready time, due date and service time
    locations = {}
    demand = {}
    ready_time = {}
    due_date = {}
    service_time = {}
    arcs = {}
    times = {}

    for index, row in enumerate(final_data):#提取信息到字典
        locations[row[0]] = (float(row[2]), float(row[3]))
        demand[row[0]] = float(row[4])
        ready_time[row[0]] = float(row[5])
        due_date[row[0]] = float(row[6])
        service_time[row[0]] = float(row[7])


    for key1, value1 in locations.items():#计算节点间的距离和行驶时间
        for key2, value2 in locations.items():
            arcs[(key1, key2)] = math.sqrt((value1[0] - value2[0])**2 + ((value1[1] - value2[1]))**2)
            times[(key1, key2)] = math.sqrt((value1[0] - value2[0])**2 + ((value1[1] - value2[1]))**2)/v


    travel_time_series = []#计算时间窗统计参数，存储每个客户的时间窗间隔
    for client in clients:
        travel_time_series.append(due_date[client] - ready_time[client])

    std = statistics.stdev(travel_time_series)#标准差
    #不同电价部分
    #n = len(original_stations)
    #random_numbers = [random.uniform(0.8, 1.5) for i in range(n)] * 3

    #result = {station: num for station, num in zip(stations, random_numbers)}

    result={'S1': 1.2262612929838004, 'S2': 0.8999999999999999, 'S3': 0.8999999999999999, 'S4': 1.4887807842875753, 'S5': 1.434371275056264, 'S6': 1.9732947748722132, 'S7': 0.8999999999999999, 'S9': 1.910534461794057, 'S10': 0.8999999999999999, 'S11': 2.1367885460900875, 'S13': 1.291285774260887, 'S17': 1.643017910669534, 'S19': 1.231287080409974}
    #不同电价部分
    normal_times = times#复制行驶时间字典

    parameters = {"Q": Q, "C": C, "g": g, "h": h, "v": v, "clients": clients, "stations": stations,
                  "all_nodes": all_nodes, "depot_start": depot_start, "depot_end": depot_end,
                  "demand": demand, "ready_time": ready_time, "due_date": due_date, "service_time": service_time,
                  "arcs": arcs, "times": times, "final_data": final_data, "original_stations": original_stations,
                  "locations": locations, "std": statistics.stdev(travel_time_series), "mean": statistics.mean(travel_time_series),
                  "time_series": travel_time_series, "normal_times": normal_times}
    parameters["transport_cost_per_unit"] = 0.36  # 单位距离运输成本
    #parameters["charge_cost_per_unit"] = 2  # 单位能量充电成本
    parameters["early_penalty_per_unit"] = 0.3  # 单位时间早到惩罚
    parameters["late_penalty_per_unit"] = 0.3  # 单位时间迟到惩罚
    parameters["refrigeration_cost_per_min"]=0.01  # 单位时间制冷成本
    parameters["damage_rate_per_min"]=0.002  # 单位时间货损率
    parameters["product_value"]=5

    parameters["station_charge_cost"] = result
    parameters["vehicle_fixed_cost"]=100


    return parameters#整合参数并返回

"""
    参数介绍
    Q:车辆电池容量（单位通常为 kWh）
    C：车辆最大载重（单位通常为 kg 或吨）
    g:充电效率相关参数（“inverse refueling rate”）
    h：能耗率（“fuel consumption rate”，单位通常为 kWh/km
    v：车辆平均行驶速度（单位通常为 km/h）
    clienta:客户节点
    stations:充电站表
    all_nodes:所有节点
    depot_start:起始仓库列表
    depot_end:终点仓库列表
    demand:原始充电站不含虚拟充电站
    ready_time:开始时间窗
    due_date:结束时间窗
    service_time:节点服务时间
    arcs:距离字典
    times:行驶时间字典
"""
"""
if __name__ == "__main__":
    # 替换为你的实例文件路径（如 Solomon 数据集的 c101.txt）
    file_path = "_instances/r105_50.txt"

    # 调用函数，获取参数
    params = get_parameters(file=file_path, num=0)  # num为可选参数
    print(params["station_charge_cost"])
    #print(params["arcs"])
    #print(params["stations"])
    
"""


